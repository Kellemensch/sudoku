# Sudoku Cell Vision > 2022-02-15 8:22pm
https://universe.roboflow.com/pete-mksb1/sudoku-cell-vision

Provided by a Roboflow user
License: CC BY 4.0

