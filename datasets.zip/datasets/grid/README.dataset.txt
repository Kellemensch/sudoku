# Sudoku Vision > v2 - 2021-12-11 1:01am
https://universe.roboflow.com/pete-mksb1/sudoku-vision

Provided by a Roboflow user
License: CC BY 4.0

